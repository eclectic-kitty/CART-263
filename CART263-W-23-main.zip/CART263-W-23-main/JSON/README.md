# JSON example

This is an example of using an API to read a JSON file
