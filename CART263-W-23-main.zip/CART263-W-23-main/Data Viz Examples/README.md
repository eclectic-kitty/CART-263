# This is an example of a Data Visualizaiton proejct 

There is a data set of EVA space walk data, make sure to include it. By default, it doesn't run any visualizations Run .drawBasic(); or .drawCircle(); to see some effects. 
